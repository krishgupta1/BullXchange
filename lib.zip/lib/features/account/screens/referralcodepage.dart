import 'package:flutter/material.dart';

import 'package:flutter/services.dart'; // Required for Clipboard
import 'package:dotted_border/dotted_border.dart'; // Make sure you have this package

class ReferralCodePage extends StatelessWidget {
  const ReferralCodePage({super.key});

  final String _referralCode = "TRADEBASE";

  @override
  Widget build(BuildContext context) {
    // --- ⭐️ Theme se colors lo ---
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final textTheme = theme.textTheme;

    return Scaffold(
      // --- ⭐️ MODIFIED: Theme background color ---
      backgroundColor: theme.scaffoldBackgroundColor,
      appBar: AppBar(
        // --- ⭐️ MODIFIED: Theme app bar colors ---
        backgroundColor: theme.appBarTheme.backgroundColor,
        elevation: 0,
        scrolledUnderElevation: 0,

        leading: IconButton(
          icon: Icon(Icons.arrow_back_ios_new, color: colorScheme.secondary),
          onPressed: () => Navigator.of(context).pop(),
        ),

        title: Text(
          'Referral Code',
          // --- ⭐️⭐️ FIX: 'color' override hata diya ⭐️⭐️ ---
          // Ab yeh theme_provider.dart se color lega
          // (Light mode mein blue, Dark mode mein white)
          style: theme.appBarTheme.titleTextStyle?.copyWith(fontSize: 20),
        ),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const SizedBox(height: 30),

            // --- Illustration ---
            Image.asset(
              'assets/images/refer_page.png',
              height: 250,
              fit: BoxFit.contain,
              errorBuilder: (context, error, stackTrace) {
                return Container(
                  height: 250,
                  color: colorScheme.surface,
                  alignment: Alignment.center,
                  child: Text(
                    'Error: Image not found\n at assets/images/refer_page.png',
                    textAlign: TextAlign.center,
                    style: TextStyle(color: colorScheme.error, fontSize: 12),
                  ),
                );
              },
            ),
            const SizedBox(height: 40),

            // --- "Refer & Earn" Title ---
            Text(
              'Refer & Earn',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
                color: colorScheme.onSurface,
              ),
            ),
            const SizedBox(height: 16),

            // --- Description Text ---
            Text(
              'Share this code with your friend and\nboth of you will get \$10 free stocks.',
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 16,
                color: textTheme.bodySmall?.color,
                height: 1.5,
              ),
            ),
            const SizedBox(height: 32),

            // --- Referral Code Box (with DottedBorder) ---
            DottedBorder(
              color: colorScheme.secondary,
              strokeWidth: 3.0,
              borderType: BorderType.RRect,
              radius: const Radius.circular(24),
              dashPattern: const [8, 4],
              padding: EdgeInsets.zero,
              child: Container(
                width: double.infinity,
                padding: const EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 20,
                ),
                decoration: BoxDecoration(
                  color: colorScheme.surface,
                  borderRadius: BorderRadius.circular(24),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      _referralCode,
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                        color: colorScheme.onSurface,
                        letterSpacing: 1.1,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Clipboard.setData(
                          ClipboardData(text: _referralCode),
                        ).then((_) {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text('Referral code copied!'),
                              backgroundColor: Colors.green,
                            ),
                          );
                        });
                      },
                      borderRadius: BorderRadius.circular(20),
                      child: Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Row(
                          children: [
                            Icon(
                              Icons.content_copy,
                              color: colorScheme.secondary,
                              size: 22,
                            ),
                            const SizedBox(width: 8),
                            Text(
                              'Copy Code',
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: colorScheme.secondary,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 32),

            // --- "Refer friend" Button ---
            SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: () {
                  // TODO: Add share logic
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: colorScheme.primary,
                  elevation: 0,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(30),
                  ),
                ),
                child: Text(
                  'Refer friend',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: colorScheme.onPrimary,
                  ),
                ),
              ),
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}
